<?php
/**
 * Plugin Name:  Limitless Cost Estimator
 * Plugin URI:   https://limitlessbranding.co
 * Description:  A live DTF transfer cost estimator. Add it to any page with the shortcode [limitless_cost_estimator].
 * Version:      1.3.1
 * Author:       Limitless Branding Co
 * License:      GPL-2.0+
 * Text Domain:  limitless-cost-estimator
 */

// ──────────────────────────────────────────────────────────────
// Security: prevent direct file access.
// ──────────────────────────────────────────────────────────────
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ──────────────────────────────────────────────────────────────
// Constants
// ──────────────────────────────────────────────────────────────
define( 'LCE_VERSION',     '1.3.1' );
define( 'LCE_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'LCE_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );


// ══════════════════════════════════════════════════════════════
// SECTION 1 — FRONT-END ASSETS
// ══════════════════════════════════════════════════════════════

/**
 * Enqueue the plugin's stylesheet and script, then pass saved
 * settings to the script via wp_localize_script so the calculator
 * uses admin-configured values instead of hardcoded constants.
 */
function lce_enqueue_assets() {

    wp_enqueue_style(
        'limitless-cost-estimator',
        LCE_PLUGIN_URL . 'assets/css/limitless-cost-estimator.css',
        [],
        LCE_VERSION
    );

    wp_enqueue_script(
        'limitless-cost-estimator',
        LCE_PLUGIN_URL . 'assets/js/limitless-cost-estimator.js',
        [],
        LCE_VERSION,
        true
    );

    $general = lce_get_general_settings();

    wp_localize_script(
        'limitless-cost-estimator',
        'lceSettings',
        [
            'rollWidth'             => (float) $general['printable_width'],
            'gap'                   => (float) $general['gap_between_designs'],
            'minBillableLI'         => (float) $general['min_billable_li'],
            'freeShippingThreshold' => (float) $general['free_shipping_threshold'],
            'pricingTiers'          => lce_get_pricing_tiers_for_js(),
        ]
    );
}
add_action( 'wp_enqueue_scripts', 'lce_enqueue_assets' );


// ══════════════════════════════════════════════════════════════
// SECTION 2 — SHORTCODE
// [limitless_cost_estimator] outputs the full calculator HTML.
// ══════════════════════════════════════════════════════════════

/**
 * Build and return the calculator HTML.
 * Important Notes are now rendered from the saved admin settings
 * rather than being hard-coded.
 */
function lce_render_calculator() {

    $c     = lce_get_colors();
    $notes = lce_get_important_notes();

    ob_start();
    ?>

    <style>
        #lce-calculator {
            --lce-teal:    <?php echo esc_attr( $c['teal']    ); ?>;
            --lce-black:   <?php echo esc_attr( $c['black']   ); ?>;
            --lce-white:   <?php echo esc_attr( $c['white']   ); ?>;
            --lce-bg:      <?php echo esc_attr( $c['bg']      ); ?>;
            --lce-divider: <?php echo esc_attr( $c['divider'] ); ?>;
        }
    </style>

    <div class="lce-calculator" id="lce-calculator">

        <!-- ═══════════════════════════════════════════════════
             TOP ROW  —  Designs card (left) + Summary card (right)
             ═══════════════════════════════════════════════════ -->
        <div class="lce-top-row">

            <!-- ───────────────────────────────────────────────
                 LEFT CARD — "Your Designs"
                 ─────────────────────────────────────────────── -->
            <div class="lce-card lce-designs-card">

                <h2 class="lce-card-title">YOUR DESIGNS</h2>

                <div class="lce-table-scroll">

                    <div class="lce-table-header" aria-hidden="true">
                        <span></span>
                        <span>Width (in)</span>
                        <span>Height (in)</span>
                        <span>Quantity</span>
                        <span>Linear Inches</span>
                        <span>Cost Per Transfer</span>
                        <span></span>
                    </div>

                    <div id="lce-design-rows"></div>

                </div><!-- /.lce-table-scroll -->

                <button class="lce-add-btn" id="lce-add-design" type="button">
                    <span class="lce-add-icon" aria-hidden="true">+</span>
                    <span class="lce-add-text">
                        <span class="lce-add-label">ADD ANOTHER DESIGN</span>
                        <span class="lce-add-sub">Add more designs to update your estimate</span>
                    </span>
                </button>

            </div><!-- /.lce-designs-card -->

            <!-- ───────────────────────────────────────────────
                 RIGHT CARD — "Estimate Summary"
                 ─────────────────────────────────────────────── -->
            <div class="lce-card lce-summary-card">

                <h2 class="lce-card-title">ESTIMATE SUMMARY</h2>

                <div class="lce-summary-block">
                    <p class="lce-summary-label">Total Linear Inches</p>
                    <p class="lce-summary-value lce-summary-large" id="lce-total-li">0 in</p>
                </div>

                <div class="lce-divider"></div>

                <div class="lce-summary-block">
                    <p class="lce-summary-label">Price Per Linear Inch</p>
                    <div class="lce-tier-row">
                        <p class="lce-summary-value lce-summary-large" id="lce-price-per-in">$0.00</p>
                        <span class="lce-tier-badge" id="lce-tier-badge"></span>
                    </div>
                </div>

                <div class="lce-divider"></div>

                <div class="lce-summary-block">
                    <p class="lce-summary-label">Estimated Total Cost</p>
                    <p class="lce-summary-value lce-summary-total" id="lce-total-cost">$0.00</p>
                </div>

                <div class="lce-shipping-area" id="lce-shipping-area" style="display:none;" aria-live="polite">
                    <p class="lce-shipping-plus" id="lce-shipping-plus">+ Shipping</p>
                    <p class="lce-shipping-note" id="lce-shipping-note"></p>
                    <div class="lce-free-badge" id="lce-free-badge">QUALIFIES FOR FREE SHIPPING!</div>
                </div><!-- /.lce-shipping-area -->

                <p class="lce-realtime-note">
                    <span aria-hidden="true">&#9432;</span>
                    All calculations update in real time
                </p>

            </div><!-- /.lce-summary-card -->

        </div><!-- /.lce-top-row -->

        <!-- ═══════════════════════════════════════════════════
             BOTTOM SECTION  —  Pricing Tiers + Important Notes
             ═══════════════════════════════════════════════════ -->
        <div class="lce-bottom-section">

            <h3 class="lce-section-title">Pricing Tiers</h3>

            <div class="lce-bottom-row">

                <div class="lce-card lce-tiers-card">
                    <h4 class="lce-tiers-card-title">PRICING TIERS (TOTAL LINEAR INCHES)</h4>
                    <div id="lce-tier-list" class="lce-tier-list"></div>
                </div>

                <div class="lce-card lce-notes-card">
                    <h4 class="lce-notes-title">IMPORTANT NOTES</h4>
                    <ul class="lce-notes-list">
                        <?php foreach ( $notes as $note ) : ?>
                            <li><?php echo esc_html( $note ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

            </div><!-- /.lce-bottom-row -->

        </div><!-- /.lce-bottom-section -->

    </div><!-- /#lce-calculator -->

    <?php
    return ob_get_clean();
}
add_shortcode( 'limitless_cost_estimator', 'lce_render_calculator' );


// ══════════════════════════════════════════════════════════════
// SECTION 3 — SETTINGS HELPERS
// ══════════════════════════════════════════════════════════════

/**
 * Return the active color palette.
 * Option keys are unchanged from v1.2.x so existing saved colors continue to work.
 */
function lce_get_colors() {
    return [
        'teal'    => get_option( 'lce_color_teal',    '#066D7E' ),
        'black'   => get_option( 'lce_color_black',   '#000000' ),
        'white'   => get_option( 'lce_color_white',   '#ffffff' ),
        'bg'      => get_option( 'lce_color_bg',      '#F2F2F2' ),
        'divider' => get_option( 'lce_color_divider', '#E6E6E6' ),
    ];
}

/**
 * Return the active general settings with numeric defaults.
 */
function lce_get_general_settings() {
    return [
        'printable_width'         => (float) get_option( 'lce_printable_width',         22.5 ),
        'gap_between_designs'     => (float) get_option( 'lce_gap_between_designs',     0.25 ),
        'min_billable_li'         => (float) get_option( 'lce_min_billable_li',         12   ),
        'free_shipping_threshold' => (float) get_option( 'lce_free_shipping_threshold', 50   ),
    ];
}

/**
 * Return the hard-coded default pricing tiers.
 * Used as a fallback when no tiers have been saved yet.
 */
function lce_get_default_pricing_tiers() {
    return [
        [ 'min' => 12,   'max' => 23,   'price' => 0.99 ],
        [ 'min' => 24,   'max' => 35,   'price' => 0.88 ],
        [ 'min' => 36,   'max' => 47,   'price' => 0.84 ],
        [ 'min' => 48,   'max' => 59,   'price' => 0.77 ],
        [ 'min' => 60,   'max' => 71,   'price' => 0.70 ],
        [ 'min' => 72,   'max' => 99,   'price' => 0.66 ],
        [ 'min' => 100,  'max' => 199,  'price' => 0.61 ],
        [ 'min' => 200,  'max' => 299,  'price' => 0.57 ],
        [ 'min' => 300,  'max' => 999,  'price' => 0.55 ],
        [ 'min' => 1000, 'max' => 1999, 'price' => 0.53 ],
        [ 'min' => 2000, 'max' => 4999, 'price' => 0.52 ],
        [ 'min' => 5000, 'max' => '',   'price' => 0.50 ],
    ];
}

/**
 * Return saved pricing tiers from the DB, or fall back to defaults.
 */
function lce_get_pricing_tiers() {
    $saved = get_option( 'lce_pricing_tiers', '' );
    if ( ! empty( $saved ) ) {
        $decoded = json_decode( $saved, true );
        if ( is_array( $decoded ) && ! empty( $decoded ) ) {
            return $decoded;
        }
    }
    return lce_get_default_pricing_tiers();
}

/**
 * Build a human-readable label for a pricing tier, e.g. "12″–23″" or "5,000″+".
 *
 * @param int|float  $min
 * @param int|string $max  Empty string means "and up".
 * @return string
 */
function lce_build_tier_label( $min, $max ) {
    $min_str = number_format( (int) $min ) . "\xE2\x80\xB3"; // ″ (double prime)
    if ( '' === $max || null === $max ) {
        return $min_str . '+';
    }
    return $min_str . "\xE2\x80\x93" . number_format( (int) $max ) . "\xE2\x80\xB3"; // –
}

/**
 * Return pricing tiers formatted for wp_localize_script.
 * max is null (not '') so JavaScript can detect it as "Infinity".
 */
function lce_get_pricing_tiers_for_js() {
    $tiers  = lce_get_pricing_tiers();
    $result = [];
    foreach ( $tiers as $tier ) {
        $raw_max  = isset( $tier['max'] ) ? $tier['max'] : '';
        $js_max   = ( '' === $raw_max || null === $raw_max ) ? null : (float) $raw_max;
        $result[] = [
            'min'   => (float) $tier['min'],
            'max'   => $js_max,
            'price' => (float) $tier['price'],
            'label' => lce_build_tier_label( $tier['min'], $raw_max ),
        ];
    }
    return $result;
}

/**
 * Return the hard-coded default important notes.
 */
function lce_get_default_notes() {
    return [
        'Prices shown are estimates and are not guaranteed.',
        "We account for a 0.25\xE2\x80\xB3 gap between each transfer.",
        'Calculations are made without nesting designs next to each other.',
        'This tool is intended only for Custom Length DTF Gang Sheet estimates.',
        'This tool will not work for gang sheets built directly on the site.',
    ];
}

/**
 * Return saved important notes from the DB, or fall back to defaults.
 */
function lce_get_important_notes() {
    $saved = get_option( 'lce_important_notes', '' );
    if ( ! empty( $saved ) ) {
        $decoded = json_decode( $saved, true );
        if ( is_array( $decoded ) && ! empty( $decoded ) ) {
            return $decoded;
        }
    }
    return lce_get_default_notes();
}


// ══════════════════════════════════════════════════════════════
// SECTION 4 — ADMIN MENU
// Registers a top-level WordPress admin menu item.
// ══════════════════════════════════════════════════════════════

function lce_admin_menu() {
    add_menu_page(
        'Limitless Cost Estimator Settings', // Page <title>
        'Limitless Estimator',               // Menu label
        'manage_options',                    // Required capability
        'limitless-cost-estimator',          // Menu slug
        'lce_render_settings_page',          // Callback
        'dashicons-calculator',              // Icon
        80                                   // Position (after Settings)
    );
}
add_action( 'admin_menu', 'lce_admin_menu' );


// ══════════════════════════════════════════════════════════════
// SECTION 5 — ADMIN SETTINGS PAGE
// Tabbed interface: General | Colors | Pricing Tiers | Important Notes
// ══════════════════════════════════════════════════════════════

/**
 * Main settings page callback. Handles tab routing and form saves.
 */
function lce_render_settings_page() {

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $valid_tabs = [ 'general', 'colors', 'tiers', 'notes' ];
    $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';
    if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
        $active_tab = 'general';
    }

    $notice = '';

    // ── General tab save ─────────────────────────────────────
    if ( 'general' === $active_tab && isset( $_POST['lce_save_general'] ) ) {
        if ( check_admin_referer( 'lce_save_general_nonce' ) ) {
            $pw  = isset( $_POST['lce_printable_width'] )         ? floatval( wp_unslash( $_POST['lce_printable_width'] ) )         : 22.5;
            $gap = isset( $_POST['lce_gap_between_designs'] )     ? floatval( wp_unslash( $_POST['lce_gap_between_designs'] ) )     : 0.25;
            $mli = isset( $_POST['lce_min_billable_li'] )         ? floatval( wp_unslash( $_POST['lce_min_billable_li'] ) )         : 12;
            $fst = isset( $_POST['lce_free_shipping_threshold'] ) ? floatval( wp_unslash( $_POST['lce_free_shipping_threshold'] ) ) : 50;

            update_option( 'lce_printable_width',         max( 0.01, $pw  ) );
            update_option( 'lce_gap_between_designs',     max( 0,    $gap ) );
            update_option( 'lce_min_billable_li',         max( 0,    $mli ) );
            update_option( 'lce_free_shipping_threshold', max( 0,    $fst ) );

            $notice = '<div class="notice notice-success is-dismissible"><p><strong>General settings saved!</strong></p></div>';
        }
    }

    // ── Colors tab save ──────────────────────────────────────
    if ( 'colors' === $active_tab && isset( $_POST['lce_save_colors'] ) ) {
        if ( check_admin_referer( 'lce_save_colors_nonce' ) ) {
            $fields = [ 'lce_color_teal', 'lce_color_black', 'lce_color_white', 'lce_color_bg', 'lce_color_divider' ];
            foreach ( $fields as $field ) {
                if ( isset( $_POST[ $field ] ) ) {
                    update_option( $field, sanitize_hex_color( wp_unslash( $_POST[ $field ] ) ) );
                }
            }
            $notice = '<div class="notice notice-success is-dismissible"><p><strong>Colors saved!</strong> Visit your page to see the changes.</p></div>';
        }
    }

    // ── Pricing Tiers tab save ───────────────────────────────
    if ( 'tiers' === $active_tab && isset( $_POST['lce_save_tiers'] ) ) {
        if ( check_admin_referer( 'lce_save_tiers_nonce' ) ) {
            $tiers = [];
            if ( isset( $_POST['lce_tiers'] ) && is_array( $_POST['lce_tiers'] ) ) {
                foreach ( $_POST['lce_tiers'] as $tier ) {
                    if ( ! is_array( $tier ) ) {
                        continue;
                    }
                    $min     = isset( $tier['min'] )   ? floatval( wp_unslash( $tier['min'] ) )              : null;
                    $raw_max = isset( $tier['max'] )   ? trim( sanitize_text_field( wp_unslash( $tier['max'] ) ) ) : '';
                    $price   = isset( $tier['price'] ) ? floatval( wp_unslash( $tier['price'] ) )            : null;

                    if ( null === $min || $min < 0 || null === $price || $price <= 0 ) {
                        continue;
                    }

                    $tiers[] = [
                        'min'   => $min,
                        'max'   => ( '' !== $raw_max ) ? floatval( $raw_max ) : '',
                        'price' => $price,
                    ];
                }
            }
            if ( ! empty( $tiers ) ) {
                update_option( 'lce_pricing_tiers', wp_json_encode( $tiers ) );
                $notice = '<div class="notice notice-success is-dismissible"><p><strong>Pricing tiers saved!</strong></p></div>';
            } else {
                $notice = '<div class="notice notice-error is-dismissible"><p><strong>No valid tiers found. Tiers were not saved.</strong></p></div>';
            }
        }
    }

    // ── Important Notes tab save ─────────────────────────────
    if ( 'notes' === $active_tab && isset( $_POST['lce_save_notes'] ) ) {
        if ( check_admin_referer( 'lce_save_notes_nonce' ) ) {
            $notes = [];
            if ( isset( $_POST['lce_notes'] ) && is_array( $_POST['lce_notes'] ) ) {
                foreach ( $_POST['lce_notes'] as $note ) {
                    $clean = sanitize_text_field( wp_unslash( $note ) );
                    if ( '' !== $clean ) {
                        $notes[] = $clean;
                    }
                }
            }
            if ( ! empty( $notes ) ) {
                update_option( 'lce_important_notes', wp_json_encode( $notes ) );
                $notice = '<div class="notice notice-success is-dismissible"><p><strong>Notes saved!</strong></p></div>';
            } else {
                $notice = '<div class="notice notice-error is-dismissible"><p><strong>No valid notes found. Notes were not saved.</strong></p></div>';
            }
        }
    }

    // ── Page output ──────────────────────────────────────────
    ?>
    <style>
        /* Admin page shared styles */
        .lce-admin-row {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 9px 0;
            border-bottom: 1px solid #e2e2e2;
        }
        .lce-admin-row:last-child { border-bottom: none; }
        #lce-admin-tiers,
        #lce-admin-notes {
            max-width: 680px;
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 3px;
            padding: 0 16px 4px;
            margin-bottom: 12px;
        }
        .lce-admin-col-header {
            display: flex;
            gap: 8px;
            padding: 8px 0 6px;
            border-bottom: 2px solid #e2e2e2;
            margin-bottom: 2px;
        }
        .lce-admin-col-header span {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            color: #646970;
        }
        .lch-min   { width: 90px; flex-shrink: 0; }
        .lch-sep   { width: 14px; flex-shrink: 0; }
        .lch-max   { width: 130px; flex-shrink: 0; }
        .lch-at    { width: 22px; flex-shrink: 0; }
        .lch-price { width: 90px; flex-shrink: 0; }
        .lce-admin-row input[type="number"] { height: 30px; }
        .lce-admin-row input[type="text"]   { flex: 1; height: 30px; }
        .lce-admin-sep { color: #999; font-size: 13px; }
    </style>

    <div class="wrap">
        <h1>Limitless Cost Estimator Settings</h1>

        <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput ?>

        <nav class="nav-tab-wrapper" style="margin-bottom:0;">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=limitless-cost-estimator&tab=general' ) ); ?>"
               class="nav-tab <?php echo ( 'general' === $active_tab ) ? 'nav-tab-active' : ''; ?>">
                General
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=limitless-cost-estimator&tab=colors' ) ); ?>"
               class="nav-tab <?php echo ( 'colors' === $active_tab ) ? 'nav-tab-active' : ''; ?>">
                Colors
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=limitless-cost-estimator&tab=tiers' ) ); ?>"
               class="nav-tab <?php echo ( 'tiers' === $active_tab ) ? 'nav-tab-active' : ''; ?>">
                Pricing Tiers
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=limitless-cost-estimator&tab=notes' ) ); ?>"
               class="nav-tab <?php echo ( 'notes' === $active_tab ) ? 'nav-tab-active' : ''; ?>">
                Important Notes
            </a>
        </nav>

        <div style="background:#fff; border:1px solid #c3c4c7; border-top:none; padding:20px 24px 24px; max-width:900px;">
            <?php
            switch ( $active_tab ) {
                case 'general':
                    lce_render_tab_general();
                    break;
                case 'colors':
                    lce_render_tab_colors();
                    break;
                case 'tiers':
                    lce_render_tab_tiers();
                    break;
                case 'notes':
                    lce_render_tab_notes();
                    break;
            }
            ?>
        </div>

        <p style="margin-top:24px;">
            <strong>Shortcode:</strong>
            <code style="font-size:15px; padding:6px 10px; background:#f0f0f0; border-radius:3px; display:inline-block;">[limitless_cost_estimator]</code>
        </p>

    </div><!-- /.wrap -->
    <?php
}


// ─────────────────────────────────────────────────────────────
// Tab: General
// ─────────────────────────────────────────────────────────────

function lce_render_tab_general() {
    $g = lce_get_general_settings();
    ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'lce_save_general_nonce' ); ?>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="lce_printable_width">Printable Width</label>
                    </th>
                    <td>
                        <input type="number"
                               name="lce_printable_width"
                               id="lce_printable_width"
                               value="<?php echo esc_attr( $g['printable_width'] ); ?>"
                               step="0.01" min="0.01"
                               style="width:120px;">
                        <span class="description"> inches &nbsp;(default: 22.5)</span>
                        <p class="description">The printable width of your roll in inches.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_gap_between_designs">Gap Between Designs</label>
                    </th>
                    <td>
                        <input type="number"
                               name="lce_gap_between_designs"
                               id="lce_gap_between_designs"
                               value="<?php echo esc_attr( $g['gap_between_designs'] ); ?>"
                               step="0.01" min="0"
                               style="width:120px;">
                        <span class="description"> inches &nbsp;(default: 0.25)</span>
                        <p class="description">The spacing added between transfers.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_min_billable_li">Minimum Billable Linear Inches</label>
                    </th>
                    <td>
                        <input type="number"
                               name="lce_min_billable_li"
                               id="lce_min_billable_li"
                               value="<?php echo esc_attr( $g['min_billable_li'] ); ?>"
                               step="0.01" min="0"
                               style="width:120px;">
                        <span class="description"> inches &nbsp;(default: 12)</span>
                        <p class="description">The minimum billable sheet length.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_free_shipping_threshold">Free Shipping Threshold</label>
                    </th>
                    <td>
                        <input type="number"
                               name="lce_free_shipping_threshold"
                               id="lce_free_shipping_threshold"
                               value="<?php echo esc_attr( $g['free_shipping_threshold'] ); ?>"
                               step="0.01" min="0"
                               style="width:120px;">
                        <span class="description"> dollars &nbsp;(default: 50)</span>
                        <p class="description">The estimated order total required to qualify for free shipping.</p>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="lce_save_general" class="button button-primary" value="Save General Settings">
        </p>
    </form>
    <?php
}


// ─────────────────────────────────────────────────────────────
// Tab: Colors
// ─────────────────────────────────────────────────────────────

function lce_render_tab_colors() {
    $c = lce_get_colors();
    ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'lce_save_colors_nonce' ); ?>

        <p>Adjust the calculator's color palette. Changes take effect immediately on the front end.</p>

        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="lce_color_teal">Primary / Teal Color</label>
                    </th>
                    <td>
                        <input type="color" name="lce_color_teal" id="lce_color_teal"
                               value="<?php echo esc_attr( $c['teal'] ); ?>">
                        <p class="description">Used for headings, badges, the Add button, and tier highlights. Default: #066D7E</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_color_black">Text / Black Color</label>
                    </th>
                    <td>
                        <input type="color" name="lce_color_black" id="lce_color_black"
                               value="<?php echo esc_attr( $c['black'] ); ?>">
                        <p class="description">Main body text color. Default: #000000</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_color_white">Card Background Color</label>
                    </th>
                    <td>
                        <input type="color" name="lce_color_white" id="lce_color_white"
                               value="<?php echo esc_attr( $c['white'] ); ?>">
                        <p class="description">Background color for all white cards. Default: #ffffff</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_color_bg">Page Background Color</label>
                    </th>
                    <td>
                        <input type="color" name="lce_color_bg" id="lce_color_bg"
                               value="<?php echo esc_attr( $c['bg'] ); ?>">
                        <p class="description">Light gray area behind the cards. Default: #F2F2F2</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="lce_color_divider">Divider / Border Color</label>
                    </th>
                    <td>
                        <input type="color" name="lce_color_divider" id="lce_color_divider"
                               value="<?php echo esc_attr( $c['divider'] ); ?>">
                        <p class="description">Horizontal lines between rows and sections. Default: #E6E6E6</p>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="submit">
            <input type="submit" name="lce_save_colors" class="button button-primary" value="Save Colors">
        </p>
    </form>
    <?php
}


// ─────────────────────────────────────────────────────────────
// Tab: Pricing Tiers
// ─────────────────────────────────────────────────────────────

function lce_render_tab_tiers() {
    $tiers    = lce_get_pricing_tiers();
    $defaults = lce_get_default_pricing_tiers();
    ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'lce_save_tiers_nonce' ); ?>

        <p>Define the pricing tiers used by the calculator. Leave <strong>Max</strong> blank for the final &#x221e; (and up) tier.</p>

        <div class="lce-admin-col-header" style="max-width:680px;">
            <span class="lch-min">Min LI</span>
            <span class="lch-sep"></span>
            <span class="lch-max">Max LI <span style="font-weight:400;text-transform:none;">(blank&nbsp;=&nbsp;&#x221e;)</span></span>
            <span class="lch-at"></span>
            <span class="lch-price">Price / LI</span>
        </div>

        <div id="lce-admin-tiers">
            <?php foreach ( $tiers as $i => $tier ) : ?>
            <div class="lce-admin-row">
                <input type="number"
                       name="lce_tiers[<?php echo (int) $i; ?>][min]"
                       value="<?php echo esc_attr( $tier['min'] ); ?>"
                       step="1" min="0" placeholder="Min"
                       style="width:90px;">
                <span class="lce-admin-sep">–</span>
                <input type="number"
                       name="lce_tiers[<?php echo (int) $i; ?>][max]"
                       value="<?php echo esc_attr( $tier['max'] ); ?>"
                       step="1" min="0" placeholder="Max (blank = ∞)"
                       style="width:130px;">
                <span class="lce-admin-sep">@ $</span>
                <input type="number"
                       name="lce_tiers[<?php echo (int) $i; ?>][price]"
                       value="<?php echo esc_attr( number_format( (float) $tier['price'], 2, '.', '' ) ); ?>"
                       step="0.01" min="0.01" placeholder="0.00"
                       style="width:90px;">
                <span class="lce-admin-sep">/in</span>
                <button type="button" class="button lce-remove-tier-btn" style="height:30px; line-height:28px;">Remove</button>
            </div>
            <?php endforeach; ?>
        </div>

        <p>
            <button type="button" id="lce-add-tier-btn" class="button">+ Add Tier</button>
        </p>

        <p class="submit" style="display:flex; gap:8px; align-items:center;">
            <input type="submit" name="lce_save_tiers" class="button button-primary" value="Save Pricing Tiers">
            <button type="button" id="lce-reset-tiers-btn" class="button">Reset to Defaults</button>
        </p>
    </form>

    <script>
    (function () {
        var container = document.getElementById('lce-admin-tiers');
        var addBtn    = document.getElementById('lce-add-tier-btn');
        var resetBtn  = document.getElementById('lce-reset-tiers-btn');
        var nextIdx   = <?php echo count( $tiers ); ?>;

        function attachRemove(row) {
            var btn = row.querySelector('.lce-remove-tier-btn');
            if (btn) {
                btn.addEventListener('click', function () { row.remove(); });
            }
        }

        function buildTierRow(idx, min, max, price) {
            var row        = document.createElement('div');
            row.className  = 'lce-admin-row';
            var minVal     = (min  !== undefined && min  !== null) ? min  : '';
            var maxVal     = (max  !== undefined && max  !== null) ? max  : '';
            var priceVal   = (price !== undefined && price !== null)
                             ? parseFloat(price).toFixed(2) : '';
            row.innerHTML  =
                '<input type="number" name="lce_tiers[' + idx + '][min]"'
              +   ' value="' + minVal + '" step="1" min="0" placeholder="Min" style="width:90px; height:30px;">'
              + '<span class="lce-admin-sep">\u2013</span>'
              + '<input type="number" name="lce_tiers[' + idx + '][max]"'
              +   ' value="' + maxVal + '" step="1" min="0" placeholder="Max (blank = \u221e)" style="width:130px; height:30px;">'
              + '<span class="lce-admin-sep">@ $</span>'
              + '<input type="number" name="lce_tiers[' + idx + '][price]"'
              +   ' value="' + priceVal + '" step="0.01" min="0.01" placeholder="0.00" style="width:90px; height:30px;">'
              + '<span class="lce-admin-sep">/in</span>'
              + '<button type="button" class="button lce-remove-tier-btn" style="height:30px; line-height:28px;">Remove</button>';
            return row;
        }

        // Wire existing remove buttons
        container.querySelectorAll('.lce-admin-row').forEach(attachRemove);

        addBtn.addEventListener('click', function () {
            var row = buildTierRow(nextIdx++, '', '', '');
            container.appendChild(row);
            attachRemove(row);
            row.querySelector('input').focus();
        });

        resetBtn.addEventListener('click', function () {
            if (!confirm('Reset all pricing tiers to defaults? Current edits will be lost unless you have already saved.')) { return; }
            var defaults = <?php echo wp_json_encode( $defaults ); ?>;
            container.innerHTML = '';
            nextIdx = 0;
            defaults.forEach(function (t) {
                var row = buildTierRow(nextIdx++, t.min, t.max, t.price);
                container.appendChild(row);
                attachRemove(row);
            });
        });
    }());
    </script>
    <?php
}


// ─────────────────────────────────────────────────────────────
// Tab: Important Notes
// ─────────────────────────────────────────────────────────────

function lce_render_tab_notes() {
    $notes    = lce_get_important_notes();
    $defaults = lce_get_default_notes();
    ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'lce_save_notes_nonce' ); ?>

        <p>These notes appear in the <strong>Important Notes</strong> section of the calculator on the front end.</p>

        <div id="lce-admin-notes">
            <?php foreach ( $notes as $note ) : ?>
            <div class="lce-admin-row">
                <input type="text" name="lce_notes[]"
                       value="<?php echo esc_attr( $note ); ?>">
                <button type="button" class="button lce-remove-note-btn" style="height:30px; line-height:28px; flex-shrink:0;">Remove</button>
            </div>
            <?php endforeach; ?>
        </div>

        <p>
            <button type="button" id="lce-add-note-btn" class="button">+ Add Note</button>
        </p>

        <p class="submit" style="display:flex; gap:8px; align-items:center;">
            <input type="submit" name="lce_save_notes" class="button button-primary" value="Save Notes">
            <button type="button" id="lce-reset-notes-btn" class="button">Reset to Defaults</button>
        </p>
    </form>

    <script>
    (function () {
        var container = document.getElementById('lce-admin-notes');
        var addBtn    = document.getElementById('lce-add-note-btn');
        var resetBtn  = document.getElementById('lce-reset-notes-btn');

        function buildNoteRow(text) {
            var row       = document.createElement('div');
            row.className = 'lce-admin-row';
            var input     = document.createElement('input');
            input.type    = 'text';
            input.name    = 'lce_notes[]';
            input.value   = text || '';
            input.style.flex = '1';
            var btn       = document.createElement('button');
            btn.type      = 'button';
            btn.className = 'button lce-remove-note-btn';
            btn.textContent = 'Remove';
            btn.style.cssText = 'height:30px; line-height:28px; flex-shrink:0;';
            btn.addEventListener('click', function () { row.remove(); });
            row.appendChild(input);
            row.appendChild(btn);
            return row;
        }

        // Wire existing remove buttons
        container.querySelectorAll('.lce-remove-note-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                btn.closest('.lce-admin-row').remove();
            });
        });

        addBtn.addEventListener('click', function () {
            var row = buildNoteRow('');
            container.appendChild(row);
            row.querySelector('input').focus();
        });

        resetBtn.addEventListener('click', function () {
            if (!confirm('Reset all notes to defaults? Current edits will be lost unless you have already saved.')) { return; }
            var defaults = <?php echo wp_json_encode( $defaults ); ?>;
            container.innerHTML = '';
            defaults.forEach(function (note) {
                container.appendChild(buildNoteRow(note));
            });
        });
    }());
    </script>
    <?php
}
